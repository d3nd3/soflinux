#! /bin/sh
# Generic demo launch script, to be called from within a makeself archive
# Change this to the name of the executable to run

DEMO=sof_demo

more README
echo
echo -n 'Would you like to play the demo now ? [Y/n] '
read answer

if [ x$answer = x -o x$answer = xy -o x$answer = xY ]; then
	echo "Launching the demo..."
	exec ./$DEMO $*
fi
echo "Run '$DEMO' at a later time to launch the game."
